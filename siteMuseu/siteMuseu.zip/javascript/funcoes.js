/**
 * @author rogiel
 */
function slide1() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00660.jpg";
	setTimeout("slide2()", 1000);
}

function slide2() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00661.jpg";
	setTimeout("slide3()", 1000)
}

function slide3() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00662.jpg";
	setTimeout("slide4()", 1000);
}
function slide4() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00663.jpg";
	setTimeout("slide5()", 1000);
}
function slide5() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00664.jpg";
	setTimeout("slide6()", 1000);
}
function slide6() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00665.jpg";
	setTimeout("slide7()", 1000);
}
function slide7() {
	document.getElementById('id').src = "../images/ImagensSlides/slideIMG_00666.jpg";
	setTimeout("slide1()", 1000);
}


function slidePrincipal1() {
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00660.jpg";
	setTimeout("slidePrincipal2()", 1000);
}

function slidePrincipal2() {
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00661.jpg";
	setTimeout("slidePrincipal3()", 1000);
}

function slidePrincipal3() {
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00662.jpg";
	setTimeout("slidePrincipal4()", 1000);
}
function slidePrincipal4(){
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00663.jpg";
	setTimeout("slidePrincipal5()", 1000);
}
function slidePrincipal5(){
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00664.jpg";
	setTimeout("slidePrincipal6()", 1000);
}
function slidePrincipal6() {
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00665.jpg";
	setTimeout("slidePrincipal7()", 1000);
}
function slidePrincipal7(){
	document.getElementById('id').src = "images/ImagensSlides/slideIMG_00666.jpg";
	setTimeout("slidePrincipal1()", 1000);
}

